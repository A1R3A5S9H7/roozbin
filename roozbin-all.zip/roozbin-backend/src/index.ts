import { Hono } from 'hono'
import { createMiddleware } from 'hono/factory'

type Env = {
  Bindings: { DB: D1Database; RESEND_API_KEY?: string; MAIL_FROM?: string }
  Variables: { userId: string }
}

const app = new Hono<Env>()

const SESSION_MS = 60 * 24 * 3600 * 1000
const RESET_MS = 15 * 60 * 1000
const PBKDF2_ITERATIONS = 100_000 // Workers WebCrypto maximum
const KINDS = new Set(['activity', 'task', 'habit', 'habit_log', 'goal', 'mood', 'settings'])
const ID_RE = /^[A-Za-z0-9_-]{1,64}$/
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
const CODE_ALPHABET = 'abcdefghjkmnpqrstuvwxyz23456789'

// ---------- crypto helpers ----------
const hex = (b: Uint8Array) => Array.from(b, (x) => x.toString(16).padStart(2, '0')).join('')
const unhex = (s: string) => new Uint8Array((s.match(/../g) ?? []).map((h) => parseInt(h, 16)))

async function sha256(s: string) {
  return hex(new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(s))))
}

function safeEqual(a: string, b: string) {
  if (a.length !== b.length) return false
  let d = 0
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i)
  return d === 0
}

async function pbkdf2(password: string, salt: Uint8Array, iterations: number) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveBits'])
  const bits = await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256)
  return hex(new Uint8Array(bits))
}

async function hashPassword(password: string) {
  const salt = crypto.getRandomValues(new Uint8Array(16))
  return `pbkdf2$${PBKDF2_ITERATIONS}$${hex(salt)}$${await pbkdf2(password, salt, PBKDF2_ITERATIONS)}`
}

const DUMMY_HASH = 'pbkdf2$100000$00000000000000000000000000000000$' + '0'.repeat(64)

async function verifyPassword(password: string, stored: string) {
  const [scheme, iter, salt, hash] = stored.split('$')
  if (scheme !== 'pbkdf2') return false
  return safeEqual(await pbkdf2(password, unhex(salt), Number(iter)), hash)
}

function randomToken() {
  return hex(crypto.getRandomValues(new Uint8Array(32)))
}

function randomCode(n = 10) {
  const b = crypto.getRandomValues(new Uint8Array(n))
  return Array.from(b, (x) => CODE_ALPHABET[x % CODE_ALPHABET.length]).join('')
}

// ---------- shared helpers ----------
async function readJson(c: { req: { json: () => Promise<unknown> } }) {
  const body = await c.req.json().catch(() => null)
  return body && typeof body === 'object' ? (body as Record<string, unknown>) : null
}

const normEmail = (v: unknown) => (typeof v === 'string' ? v.trim().toLowerCase() : '')
const validPassword = (v: unknown): v is string => typeof v === 'string' && v.length >= 8 && v.length <= 128

async function createSession(db: D1Database, userId: string) {
  const token = randomToken()
  await db
    .prepare('INSERT INTO sessions (token_hash, user_id, expires_at) VALUES (?, ?, ?)')
    .bind(await sha256(token), userId, Date.now() + SESSION_MS)
    .run()
  return token
}

async function sendMail(env: Env['Bindings'], to: string, subject: string, text: string) {
  if (!env.RESEND_API_KEY || !env.MAIL_FROM) return
  await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: env.MAIL_FROM, to, subject, text }),
  }).catch(() => {})
}

const auth = createMiddleware<Env>(async (c, next) => {
  const m = /^Bearer ([0-9a-f]{64})$/.exec(c.req.header('Authorization') ?? '')
  if (!m) return c.json({ error: 'unauthorized' }, 401)
  const row = await c.env.DB.prepare('SELECT user_id, expires_at FROM sessions WHERE token_hash = ?')
    .bind(await sha256(m[1]))
    .first<{ user_id: string; expires_at: number }>()
  if (!row || row.expires_at < Date.now()) return c.json({ error: 'unauthorized' }, 401)
  c.set('userId', row.user_id)
  await next()
})

// ---------- routes ----------
app.get('/health', (c) => c.json({ ok: true }))

app.post('/auth/register', async (c) => {
  const body = await readJson(c)
  const email = normEmail(body?.email)
  if (!EMAIL_RE.test(email) || email.length > 254) return c.json({ error: 'invalid_email' }, 400)
  if (!validPassword(body?.password)) return c.json({ error: 'invalid_password' }, 400)
  const id = crypto.randomUUID()
  try {
    await c.env.DB.prepare('INSERT INTO users (id, email, pass_hash, created_at) VALUES (?, ?, ?, ?)')
      .bind(id, email, await hashPassword(body.password), Date.now())
      .run()
  } catch {
    return c.json({ error: 'email_taken' }, 409)
  }
  return c.json({ token: await createSession(c.env.DB, id), user: { id, email } }, 201)
})

app.post('/auth/login', async (c) => {
  const body = await readJson(c)
  const email = normEmail(body?.email)
  const password = typeof body?.password === 'string' ? body.password : ''
  const user = await c.env.DB.prepare('SELECT id, pass_hash FROM users WHERE email = ?')
    .bind(email)
    .first<{ id: string; pass_hash: string }>()
  // Always run one hash so response time doesn't reveal whether the email exists.
  const ok = await verifyPassword(password.slice(0, 128), user?.pass_hash ?? DUMMY_HASH)
  if (!user || !ok) return c.json({ error: 'invalid_credentials' }, 401)
  await c.env.DB.prepare('DELETE FROM sessions WHERE user_id = ? AND expires_at < ?').bind(user.id, Date.now()).run()
  return c.json({ token: await createSession(c.env.DB, user.id), user: { id: user.id, email } })
})

app.post('/auth/logout', auth, async (c) => {
  const m = /^Bearer (.+)$/.exec(c.req.header('Authorization') ?? '')
  if (m) await c.env.DB.prepare('DELETE FROM sessions WHERE token_hash = ?').bind(await sha256(m[1])).run()
  return c.json({ ok: true })
})

app.post('/auth/forgot', async (c) => {
  const body = await readJson(c)
  const email = normEmail(body?.email)
  const user = await c.env.DB.prepare('SELECT id FROM users WHERE email = ?').bind(email).first<{ id: string }>()
  if (user) {
    const code = randomCode()
    await c.env.DB.prepare(
      'INSERT INTO password_resets (user_id, code_hash, expires_at, attempts) VALUES (?, ?, ?, 0) ' +
        'ON CONFLICT(user_id) DO UPDATE SET code_hash = excluded.code_hash, expires_at = excluded.expires_at, attempts = 0',
    )
      .bind(user.id, await sha256(code), Date.now() + RESET_MS)
      .run()
    await sendMail(c.env, email, 'Roozbin password reset', `Your reset code (valid for 15 minutes): ${code}`)
  }
  return c.json({ ok: true }) // same answer whether or not the email exists
})

app.post('/auth/reset', async (c) => {
  const body = await readJson(c)
  const email = normEmail(body?.email)
  const code = typeof body?.code === 'string' ? body.code.trim().toLowerCase() : ''
  if (!validPassword(body?.password)) return c.json({ error: 'invalid_password' }, 400)
  const row = await c.env.DB.prepare(
    'SELECT u.id AS id, r.code_hash AS code_hash, r.expires_at AS expires_at, r.attempts AS attempts ' +
      'FROM users u JOIN password_resets r ON r.user_id = u.id WHERE u.email = ?',
  )
    .bind(email)
    .first<{ id: string; code_hash: string; expires_at: number; attempts: number }>()
  if (!row || row.expires_at < Date.now() || row.attempts >= 5) return c.json({ error: 'invalid_code' }, 400)
  if (!safeEqual(await sha256(code), row.code_hash)) {
    await c.env.DB.prepare('UPDATE password_resets SET attempts = attempts + 1 WHERE user_id = ?').bind(row.id).run()
    return c.json({ error: 'invalid_code' }, 400)
  }
  await c.env.DB.batch([
    c.env.DB.prepare('UPDATE users SET pass_hash = ? WHERE id = ?').bind(await hashPassword(body.password), row.id),
    c.env.DB.prepare('DELETE FROM password_resets WHERE user_id = ?').bind(row.id),
    c.env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(row.id),
  ])
  return c.json({ ok: true })
})

// Required by the App Store: users must be able to delete their account.
app.delete('/account', auth, async (c) => {
  const userId = c.get('userId')
  const body = await readJson(c)
  const user = await c.env.DB.prepare('SELECT pass_hash FROM users WHERE id = ?').bind(userId).first<{ pass_hash: string }>()
  const password = typeof body?.password === 'string' ? body.password.slice(0, 128) : ''
  if (!user || !(await verifyPassword(password, user.pass_hash))) return c.json({ error: 'invalid_credentials' }, 401)
  await c.env.DB.batch([
    c.env.DB.prepare('DELETE FROM records WHERE user_id = ?').bind(userId),
    c.env.DB.prepare('DELETE FROM sessions WHERE user_id = ?').bind(userId),
    c.env.DB.prepare('DELETE FROM password_resets WHERE user_id = ?').bind(userId),
    c.env.DB.prepare('DELETE FROM users WHERE id = ?').bind(userId),
  ])
  return c.json({ ok: true })
})

// Pull: GET /sync?since=<ms>. Re-pulling the same rows is harmless (client upserts by id).
app.get('/sync', auth, async (c) => {
  const since = Number(c.req.query('since') ?? 0)
  if (!Number.isFinite(since) || since < 0) return c.json({ error: 'invalid_since' }, 400)
  const LIMIT = 500
  const { results } = await c.env.DB.prepare(
    'SELECT kind, id, data, updated_at, deleted, synced_at FROM records ' +
      'WHERE user_id = ? AND synced_at >= ? ORDER BY synced_at, kind, id LIMIT ?',
  )
    .bind(c.get('userId'), since, LIMIT + 1)
    .all<{ kind: string; id: string; data: string; updated_at: number; deleted: number; synced_at: number }>()
  const hasMore = results.length > LIMIT
  const page = hasMore ? results.slice(0, LIMIT) : results
  return c.json({
    records: page.map((r) => ({
      kind: r.kind,
      id: r.id,
      data: JSON.parse(r.data),
      updated_at: r.updated_at,
      deleted: r.deleted === 1,
    })),
    has_more: hasMore,
    next_since: page.length ? page[page.length - 1].synced_at : since,
  })
})

// Push: POST /sync { records: [{ kind, id, data, updated_at, deleted }] } (max 100). Last write wins.
app.post('/sync', auth, async (c) => {
  const body = await readJson(c)
  const list = body?.records
  if (!Array.isArray(list) || list.length > 100) return c.json({ error: 'invalid_batch' }, 400)
  const now = Date.now()
  const upsert = c.env.DB.prepare(
    'INSERT INTO records (user_id, kind, id, data, updated_at, deleted, synced_at) VALUES (?, ?, ?, ?, ?, ?, ?) ' +
      'ON CONFLICT(user_id, kind, id) DO UPDATE SET data = excluded.data, updated_at = excluded.updated_at, ' +
      'deleted = excluded.deleted, synced_at = excluded.synced_at WHERE excluded.updated_at > records.updated_at',
  )
  const stmts: D1PreparedStatement[] = []
  for (const r of list as Record<string, unknown>[]) {
    if (!r || typeof r.kind !== 'string' || !KINDS.has(r.kind)) return c.json({ error: 'invalid_kind' }, 400)
    if (typeof r.id !== 'string' || !ID_RE.test(r.id)) return c.json({ error: 'invalid_id' }, 400)
    if (typeof r.updated_at !== 'number' || !Number.isFinite(r.updated_at)) return c.json({ error: 'invalid_updated_at' }, 400)
    const data = JSON.stringify(r.data ?? null)
    if (data.length > 16_384) return c.json({ error: 'record_too_large' }, 400)
    const updatedAt = Math.min(Math.trunc(r.updated_at), now + 24 * 3600 * 1000) // no far-future pinning
    stmts.push(upsert.bind(c.get('userId'), r.kind, r.id, data, updatedAt, r.deleted ? 1 : 0, now))
  }
  if (stmts.length) await c.env.DB.batch(stmts)
  return c.json({ ok: true, server_time: now })
})

app.notFound((c) => c.json({ error: 'not_found' }, 404))
app.onError((_err, c) => c.json({ error: 'server_error' }, 500))

export default app
