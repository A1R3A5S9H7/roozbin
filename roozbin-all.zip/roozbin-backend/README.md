# روزبین — بک‌اند (Cloudflare Workers + D1)

> این کد نوشته شده ولی اجرا و تست نشده (در محیط ساخت، اینترنت نبود). اولین `typecheck` و `dev` را خودتان بزنید.

## راه‌اندازی (ویندوز)
1. Node.js (نسخه LTS) را نصب کنید و یک حساب رایگان Cloudflare بسازید.
2. در پوشه‌ی پروژه: `npm install`
3. `npx wrangler login`
4. `npx wrangler d1 create roozbin` ← مقدار `database_id` را در `wrangler.toml` جایگزین کنید.
5. ساخت جدول‌ها: `npm run db:remote`
6. (اختیاری، برای بازیابی رمز) حساب Resend بسازید و دامنه‌تان را تأیید کنید:
   `npx wrangler secret put RESEND_API_KEY` و `MAIL_FROM` را در `wrangler.toml` تنظیم کنید.
7. اجرا: `npm run deploy`

## اتصال گیت‌هاب (دیپلوی خودکار)
پروژه را روی یک ریپوی گیت‌هاب بگذارید. در داشبورد Cloudflare: Workers & Pages ← Create ← Import a repository. از آن به بعد با هر push دیپلوی می‌شود.

## API
| مسیر | کار |
|---|---|
| `POST /auth/register` `{email,password}` | ثبت‌نام، برمی‌گرداند `token` |
| `POST /auth/login` | ورود |
| `POST /auth/logout` | خروج (هدر `Authorization: Bearer <token>`) |
| `POST /auth/forgot` `{email}` | ارسال کد بازنشانی به ایمیل |
| `POST /auth/reset` `{email,code,password}` | تعیین رمز جدید |
| `DELETE /account` `{password}` | حذف حساب و همه‌ی داده‌ها |
| `GET /sync?since=<ms>` | دریافت تغییرات از آن زمان به بعد |
| `POST /sync` `{records:[...]}` | ارسال تغییرات (حداکثر ۱۰۰ تا) |

رکورد همگام‌سازی: `{kind, id, data, updated_at, deleted}`. `kind` یکی از: activity, task, habit, habit_log, goal, mood, settings. `id` را اپ می‌سازد (UUID). تداخل: رکوردی که `updated_at` بزرگ‌تر دارد می‌ماند. برای دریافت، اپ `next_since` را نگه می‌دارد و دفعه‌ی بعد همان را می‌فرستد؛ تا وقتی `has_more` درست است ادامه می‌دهد.

## محدودیت‌ها و کارهای باقی‌مانده
- هش رمز با PBKDF2 (۱۰۰ هزار تکرار، سقف WebCrypto). روی پلن رایگان ممکن است به سقف زمان پردازش بخورد؛ اگر خطای ۱۱۰۲ یا Exceeded CPU دیدید، پلن پولی (حدود ۵ دلار در ماه) یا هش سبک‌تر لازم است.
- محدودیت نرخ درخواست (rate limiting) روی ورود و ثبت‌نام را باید با Cloudflare WAF یا Rate Limiting binding اضافه کنیم.
- سقف تعداد رکورد برای هر کاربر هنوز گذاشته نشده.
- قبل از انتشار: صفحه‌ی سیاست حریم خصوصی لازم است.
